var imported = require("./module_to_export.js");

console.log("Hello from module: " , imported.printhello());

console.log("Node Easy ", imported.helloCool());