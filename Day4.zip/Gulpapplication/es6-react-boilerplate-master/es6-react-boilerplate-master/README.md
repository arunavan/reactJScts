# es6-react-boilerplate

## Install

```
$ npm install
```

## Run

Either navigate to the file in your browser, or start a http server like the following and go to localhost:3000 to see the project.

```
$ python -m SimpleHTTPServer 3000
```

To make changes, run gulp so it can compile them:

```
$ gulp
```
