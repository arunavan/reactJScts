package main  
import "fmt"  
func main() {  
   for a := 0; a < 11; a++ {  
      fmt.Print(a,"\n")  
   }  
}  
