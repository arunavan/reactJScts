package main  
import (  
   "fmt"  
)  
func fun() int {  
   return 123456789  
}  
func main() {  
   x := fun()  
   fmt.Println(x)  
}  
