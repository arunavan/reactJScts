
public class java7 {

}
