package coreservlets.actionlistener;

public class ButtonFrame1Test {
  public static void main(String[] args) {
    new ButtonFrame1();
  }
}