package coreservlets.actionlistener;

public class ButtonFrame4Test {
  public static void main(String[] args) {
    new ButtonFrame4();
  }
}