package coreservlets.comparator;

public class StringSorter2Test {
  public static void main(String[] args) {
    StringSorter2 sorter = new StringSorter2();
    sorter.doTests();
  }
}
