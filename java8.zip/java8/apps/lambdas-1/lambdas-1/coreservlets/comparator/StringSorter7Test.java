package coreservlets.comparator;

public class StringSorter7Test {
  public static void main(String[] args) {
    StringSorter7.doTests();
  }
}