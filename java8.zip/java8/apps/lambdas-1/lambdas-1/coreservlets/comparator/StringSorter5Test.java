package coreservlets.comparator;

public class StringSorter5Test {
  public static void main(String[] args) {
    StringSorter5.doTests();
  }
}
