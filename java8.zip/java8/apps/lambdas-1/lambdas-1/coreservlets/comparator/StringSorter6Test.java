package coreservlets.comparator;

public class StringSorter6Test {
  public static void main(String[] args) {
    StringSorter6.doTests();
  }
}