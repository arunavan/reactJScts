var materials = [
  'Hydrogen',
  'Helium',
  'Lithium',
  'Beryllium'
];  

const city='Hyderabad';
console.log(city);
city='Chennai';
console.log(city);
console.log(materials);
console.log(materials.map(material => material.length));
