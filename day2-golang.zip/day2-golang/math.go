package main
import "fmt"
import "math"
func main() {
	fmt.Println(math.pi)
}
