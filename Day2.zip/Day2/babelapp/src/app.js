var nums=[1,2,3];
var doublenums=nums.map((e)=>e*2);