var memory = require("v8");

console.log(memory.getHeapStatistics());

//console.log(memory.getHeapSpaceStatistics());