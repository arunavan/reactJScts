var nums = [1,2,3];
var doubleNums = nums.map((e) => e * 2);