import React, { Component } from 'react';
import './App.css';

class App extends Component {
addTodo(event) {
  event.preventDefault();
  let name=this.refs.name.value;
  let done=this.refs.done.value;
  let counter=this.refs.counter;

  let todo ={
    name,done,counter
  };
  counter+=1;

  let todos =this.state.todos;

  todos.push(todo);
  
  this.setState({todos:todos,counter:counter});
  this.refs.todoForm.reset();
}

  constructor() {
    super();
    this.addTodo=this.addTodo.bind(this);
    this.state= {
      todos:[],
      title: 'Ract simple todo app',
      counter:0
    }
  }
  render() {
   // let title=this.state.title;
    let todos=this.state.todos;
    return (
      <div className="App">
       <h1>  Welcome to CTS </h1>
       <form ref="todoForm">
          <input type="text" ref="name"/>
          <input type="text" ref="done"/>
          <button onClick={this.addTodo}>Add todo </button>
          </form>
          <ul>
                {todos.map((todo => <li key={todo.counter}>{todo.name}</li> ))}
            </ul>


<pre>
  {JSON.stringify(todos)}
  </pre>
      </div>
    );
  }
}

export default App;
