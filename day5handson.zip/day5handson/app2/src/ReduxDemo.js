import React , {Component } from 'react';
import { createStore} from  'redux'
class ReduxDemo extends Component {
    render() {
//step2 : REducer : state n action
        const reducer = function (state,action) {
            if(action.type==='ATTACK'){
                return action.payload
            }
            if(action.type==='GREENATTACK'){
                return action.payload
            }
            return state;
        }
//step1 Store : reducer n state
const store=createStore(reducer,"Peace");
//step 3 :subscribe
store.subscribe(()=> {
    console.log("Store is now ",store.getState());
})
//step 4 : dispatch
//store.dispatch({type:"ATTACK",payload: "Iron Man"})
store.dispatch({type:"GREENATTACK",payload: "HULK"})
        return (
                <div>  <h1> Welcome to Redux </h1>
                </div>
                );
            }
}
export default  ReduxDemo;